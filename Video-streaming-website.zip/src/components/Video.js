import React from 'react'

const Video = () => {
  return (
    <div className='video'>
      <div className='video1'>
          <input type="search" placeholder="Search" size="15"/>
          <button> Enter </button>


          

      </div>
    </div>
  )
}

export default Video
